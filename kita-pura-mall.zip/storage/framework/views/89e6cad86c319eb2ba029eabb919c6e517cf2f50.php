


<?php $__env->startSection('title'); ?>
Toko
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-scripts'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>



<div id="modal_hapus_toko" class="modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header d-flex align-items-center">
                <h4 class="modal-title" id="myModalLabel">Hapus Toko</h4>
                <button type="button" class="close ml-auto" data-dismiss="modal" aria-hidden="true">×</button>
            </div>
            <div class="modal-body">
                <form action="<?=url('/')?>/admin/manajemen/hapus_toko" method="post">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        Ketikkan untuk menghapus toko <b>"kitapuramallpalu"</b> 
                        <p style="color: red" id="pass_salah"></p>
                        <input name="ketikan" id="ketikan" type="text" hidden value="kitapuramallpalu">
                        <input name="id_toko" id="id_toko" type="text" hidden>
                        <div class="col-sm-12">
                            <input name="pass" id="pass" type="text" class="form-control">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" onclick="cek_pass()" class="btn btn-info waves-effect">Hapus Toko</button>
                        <button id="submit" type="submit" hidden class="btn btn-info waves-effect">hidden</button>
                    </div>
                </form>
            </div>
            
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>

<div class="row">
    <div class="col-12">
        <div class="material-card card">
            <div class="card-body">
                <h4 class="card-title">Daftar Semua Toko</h4>
                <a type="button" class="btn btn-primary" href="<?=url('/')?>/admin/manajemen/daftar_tunggu_toko">
                    Daftar Tunggu
                </a>
                <br><br>
                <div class="table-responsive">
                    <table style="width: 100%" id="config-table" class="table display table-bordered table-striped no-wrap">
                        <thead>
                            <tr>
                                <th>Nama Toko</th>
                                <th>No Telp</th>
                                <th>Alamat</th>
                                <th>Kategori Toko</th>
                                <th>Jumlah Produk</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $toko; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($data->nama_toko); ?></td>
                                    <td><?php echo e($data->no_hp); ?></td>
                                    <td><?php echo e($data->alamat); ?></td>
                                    <td>
                                        <?php $__currentLoopData = $data->kategorinya_toko; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($kategori->kategori_toko->kategori); ?>,
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td><a href="<?=url('/')?>/admin/manajemen/toko/<?php echo e($data->id); ?>/daftar_produk"><?php echo e(count($data->product)); ?></a></td>
                                    <td>
                                        <a href="<?=url('/')?>/admin/manajemen/toko/<?php echo e($data->id); ?>" type="button" class="btn btn-primary">Ubah</a>
                                        <a onclick="modal_hapus('<?php echo e($data->id); ?>')" type="button" class="btn btn-danger">Hapus</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-12">
        <div class="material-card card">
            <div class="card-body">
                <h4 class="card-title">Daftar Toko Non-Aktif</h4>
                <a type="button" class="btn btn-primary" href="<?=url('/')?>/admin/manajemen/daftar_tunggu_toko">
                    Daftar Tunggu
                </a>
                <br><br>
                <div class="table-responsive">
                    <table style="width: 100%" id="config-table" class="table display table-bordered table-striped no-wrap">
                        <thead>
                            <tr>
                                <th>Nama Toko</th>
                                <th>No Telp</th>
                                <th>Alamat</th>
                                <th>Kategori Toko</th>
                                <th>Jumlah Produk</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $toko_non_aktif; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($data->nama_toko); ?></td>
                                    <td><?php echo e($data->no_hp); ?></td>
                                    <td><?php echo e($data->alamat); ?></td>
                                    <td>
                                        <?php $__currentLoopData = $data->kategorinya_toko; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($kategori->kategori_toko->kategori); ?>,
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td><a href="<?=url('/')?>/admin/manajemen/toko/<?php echo e($data->id); ?>/daftar_produk"><?php echo e(count($data->product)); ?></a></td>
                                    <td>
                                        <a href="<?=url('/')?>/admin/manajemen/toko/<?php echo e($data->id); ?>" type="button" class="btn btn-primary">Ubah</a>
                                        <a onclick="modal_hapus('<?php echo e($data->id); ?>')" type="button" class="btn btn-danger">Hapus</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
<script src="<?=url('/')?>/public/template/admin/assets/extra-libs/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?=url('/')?>/public/template/admin/assets/extra-libs/datatables.net-bs4/js/dataTables.responsive.min.js">
</script>
<script src="<?=url('/')?>/public/template/admin/dist/js/pages/datatable/datatable-basic.init.js"></script>

<script>
    function modal_hapus(id_toko){
        $('#modal_hapus_toko').modal('show');
        $('#id_toko').val(id_toko);
    }

    function cek_pass(){
        if($('#ketikan').val() != $('#pass').val()){
            $('#pass_salah').empty();
            $('#pass_salah').append("Inputan salah");
        }
        else{
            $("#submit").click();
        }
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\kita-pura-mall\resources\views/users/admin/m-toko/index.blade.php ENDPATH**/ ?>