<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="HandheldFriendly" content="true"/>
    <title><?php echo $__env->yieldContent('title'); ?>Kitapura Mall</title>
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('public/template/admin/assets/images/favicon.png')); ?>">
    <link rel="stylesheet" type="text/css" href="<?=url('/')?>/public/template/admin/dist/css/style.min.css">
    <link rel="stylesheet" type="text/css" href="<?=url('/')?>/public/css/kitapura.css">
    <?php echo $__env->yieldContent('header-scripts'); ?>
</head>

<body>
    <?php echo $__env->yieldContent("content"); ?>
</body>    
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<?php echo $__env->yieldContent('footer-scripts'); ?>


</html>
<?php /**PATH D:\xampp\htdocs\kita-pura-mall\resources\views/layouts/home_no_menu.blade.php ENDPATH**/ ?>