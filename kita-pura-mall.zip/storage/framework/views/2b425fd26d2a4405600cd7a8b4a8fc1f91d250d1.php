<?php $__currentLoopData = $tokos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $toko): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="input-group mb-3" style="margin-top: 1em; background:transparent; border: none; border-radius: 1.2em; display: flex; justify-content: center;" onclick="show_loader()">
    <div style="display: flex; justify-content: center; position:relative;width: 90%; margin: 0px; height: 13em;border-radius: 1em; ">
        <a href="<?=url('/')?>/<?php echo e($toko->username); ?>?previous=toko" style="background: #FB036B; width: 100%; border-radius: 1em;">
            <?php if($toko->foto != ''): ?>
            <img src="<?=url('/')?>/public/img/toko/<?php echo e($toko->id); ?>/cover/240x240/<?php echo e($toko->foto_cover); ?>" style="width: 100%; object-fit: cover;height: 100%; border-radius: 1em;">
            <?php else: ?>
            <img src="<?=url('/')?>/public/img/maps/template_maps.svg" style="width: 100%; height: 100%; border-radius: 1em;">
            <?php endif; ?>
        </a>
        <div class="label-product" style="position: absolute; bottom: 0em; left: 0em; padding: 0.9em 0.5em 0.9em 1.2em; display: flex; width: 100%; background-color: rgba(0,0,0,0.3); justify-content: space-between; border-bottom-left-radius: 1em; border-bottom-right-radius: 1em;">
            <div class="keterangan-product" style="display: flex;">
                <div style="width: 2em; height: 2em; border-radius: 50%; border:1px solid white;">
                    <img src="<?=url('/')?>/public/img/toko/<?php echo e($toko->id); ?>/logo/200x200/<?php echo e($toko->logo_toko); ?>" style="width: 100%; height: 100%; border-radius: 50%; object-fit:cover; ">
                </div>
                <div class="detail-keterangan-product" style="display: flex; flex-direction: column; justify-content: center; color: white; margin-left: 0.3em;">
                    <?php if(count($toko->kategorinya_toko) != 0 ): ?>
                        <div style="font-size: 0.7em; line-height: 1em;"><?php echo e(ucwords(strtolower($toko->kategorinya_toko[0]->kategori_toko->kategori))); ?></div>
                    <?php endif; ?>
                    <a href="<?=url('/')?>/<?php echo e($toko->username); ?>?previous=toko" style="font-size: 1em; line-height: 1.3em; color: white;"><?=substr(strip_tags($toko->nama_toko), 0, 15)?><?php if(strlen($toko->nama_toko) > 15): ?>..<?php endif; ?></a>
                    
                </div>
            </div>
            <?php if($toko->jenis_mitra == 'premium'): ?>
            <a href="<?=url('/')?>/<?php echo e($toko->username); ?>?previous=toko" style="background: white; padding: 0.2em 1em; color: #ff006e; border-radius: 1.5em; font-size: 0.8em; display: flex; align-items: center;">Kunjungi Toko</a>
            <?php else: ?>
            <div style="background: #ff006e; padding: 0.2em 1.1em; color: white; border-radius: 1.5em; font-size: 0.8em; display: flex; align-items: center;">Hubungi Toko</div>
            <?php endif; ?>
        </div>

    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH D:\xampp\htdocs\kita-pura-mall\resources\views/toko/toko_data.blade.php ENDPATH**/ ?>