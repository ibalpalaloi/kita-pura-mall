<?php $index = 0; ?>
<?php $__currentLoopData = $tokos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $toko): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $index++; ?>
<?php if($index%5 != 0): ?>
<div class="input-group mb-3" style="margin-top: 0em; background:transparent; border: none; border-radius: 1.2em; display: flex; justify-content: center; width: 50%;">
    <div style="display: flex; justify-content: center; position:relative;width: 92%; margin: 0px; height: 100%; border-radius: 1em; background: linear-gradient(180deg, rgba(0, 0, 0, 0) 66.15%, #000000 100%);">
        <a style="background: #FB036B; width: 100%; border-radius: 1em;">
            <?php if($toko->foto_cover != ''): ?>
            <img src="<?=url('/')?>/public/img/toko/<?php echo e($toko->id); ?>/cover/240x240/<?php echo e($toko->foto_cover); ?>" style="width: 100%;height: 100%; border-radius: 1em;">
            <?php else: ?>
            <img src="<?=url('/')?>/public/img/toko/toko_default.svg" style="width: 100%; height: 100%; border-radius: 1em;">
            <?php endif; ?>
        </a>
        <a class="overlay" onclick="show_loader()"  href="<?=url('/')?>/<?php echo e($toko->username); ?>"></a>
        <div class="label-product" style="position: absolute; bottom: 0em; left: 0em; padding: 0.5em 0.5em 0.5em 0.7em; display: flex; width: 100%; background: linear-gradient(180deg, rgba(0, 0, 0, 0) 66.15%, #000000 100%);  justify-content: space-between; border-bottom-left-radius: 1em; border-bottom-right-radius: 1em;">
            <div class="keterangan-product" style="display: flex;">
                <div style="border-radius: 50%; width: 1.8em; height: 1.8em; border:1px solid white;">
                    <?php if(file_exists(public_path("img/toko/$toko->id/logo/200x200/$toko->logo_toko"))): ?>
                    <img src="<?=url('/')?>/public/img/toko/<?php echo e($toko->id); ?>/logo/200x200/<?php echo e($toko->logo_toko); ?>" style="width: 100%; border-radius: 50%;">
                    <?php else: ?>
                    <img src="<?=url('/')?>/public/img/toko/premium.svg" style="width: 100%; border-radius: 50%;">

                    <?php endif; ?>
                </div>
                <div class="detail-keterangan-product" style="display: flex; flex-direction: column; justify-content: center; color: white; margin-left: 0.3em;">
                    <?php if($toko->jumlah_produk != 0 ): ?>
                    <div style="font-size: 0.7em; line-height: 1em;"><?php echo e($toko->jumlah_produk); ?> Produk</div>
                    <?php endif; ?>
                    <a href="<?=url('/')?>/<?php echo e($toko->username); ?>?previous=toko" style="font-size: 0.8em; line-height: 1.3em; color: white;"><?=substr(strip_tags($toko->nama_toko), 0, 12)?><?php if(strlen($toko->nama_toko) > 12): ?>..<?php endif; ?></a>
                </div>
                <div style="background: #FF006E; position: absolute; right: 0.5em; bottom: 1em; font-size: 0.7em; padding:0.2em 0.7em; color: white;border-radius: 1em;">
                    Lihat toko
                </div>
            </div>
            <?php if($toko->jenis_mitra == 'premium'): ?>
            <a href="<?=url('/')?>/<?php echo e($toko->username); ?>?previous=toko" style="background: white; padding: 0.2em 1em; color: #ff006e; border-radius: 1.5em; font-size: 0.8em; display: flex; align-items: center;" hidden>Kunjungi Toko</a>
            <?php else: ?>
            <div style="background: #ff006e; padding: 0.2em 1.1em; color: white; border-radius: 1.5em; font-size: 0.8em; display: flex; align-items: center;">Hubungi Toko</div>
            <?php endif; ?>
        </div>

    </div>
</div>
<?php else: ?>
<div class="input-group mb-3" style="margin-top: 0em; background:transparent; border: none; border-radius: 1.2em; display: flex; justify-content: center; width: 100%;" onclick="show_loader()">
    <div style="display: flex; justify-content: center; position:relative;width: 96%; margin: 0px; height: 100%; border-radius: 1em; background: linear-gradient(180deg, rgba(0, 0, 0, 0) 66.15%, #000000 100%);">
        <a href="<?=url('/')?>/<?php echo e($toko->username); ?>?previous=toko" style="background: #FB036B; width: 100%; border-radius: 1em;">
            <?php if($toko->foto_cover != ''): ?>
            <img src="<?=url('/')?>/public/img/toko/<?php echo e($toko->id); ?>/cover/240x240/<?php echo e($toko->foto_cover); ?>" style="width: 100%;height: 100%; border-radius: 1em;">
            <?php else: ?>
            <img src="<?=url('/')?>/public/img/toko/toko_default.svg" style="width: 100%; height: 100%; border-radius: 1em;">
            <?php endif; ?>
        </a>
        <a onclick="show_loader()" href="<?=url('/')?>/<?php echo e($toko->username); ?>" class="overlay"></a>
        <div class="label-product" style="position: absolute; bottom: 0em; left: 0em; padding: 0.5em 0.5em 1em 1em; display: flex; width: 100%; background: linear-gradient(180deg, rgba(0, 0, 0, 0) 66.15%, #000000 100%);  justify-content: space-between; border-bottom-left-radius: 1em; border-bottom-right-radius: 1em;">
            <div class="keterangan-product" style="display: flex;">
                <div style="border-radius: 50%; width: 2.8em; height: 2.8em; border:1px solid white;">
                    <?php if(file_exists(public_path("img/toko/$toko->id/logo/200x200/$toko->logo_toko"))): ?>
                    <img src="<?=url('/')?>/public/img/toko/<?php echo e($toko->id); ?>/logo/200x200/<?php echo e($toko->logo_toko); ?>" style="width: 100%; border-radius: 50%;">
                    <?php else: ?>
                    <img src="<?=url('/')?>/public/img/toko/premium.svg" style="width: 100%; border-radius: 50%;">

                    <?php endif; ?>
                </div>
                <div class="detail-keterangan-product" style="display: flex; flex-direction: column; justify-content: center; color: white; margin-left: 0.3em;">
                    <?php if($toko->jumlah_produk != 0 ): ?>
                    <div style="font-size: 1em; line-height: 1em;"><?php echo e($toko->jumlah_produk); ?> Produk</div>
                    <?php endif; ?>
                    <a href="<?=url('/')?>/<?php echo e($toko->username); ?>?previous=toko" style="font-size: 1.2em; line-height: 1.3em; color: white;"><?=substr(strip_tags($toko->nama_toko), 0, 16)?><?php if(strlen($toko->nama_toko) > 16): ?>..<?php endif; ?></a>
                </div>
                <div style="background: #FF006E; position: absolute; right: 0.5em; bottom: 1.1em; font-size: 1.1em; padding:0.2em 0.7em; color: white;border-radius: 1em;">
                    Lihat toko
                </div>
            </div>
            <?php if($toko->jenis_mitra == 'premium'): ?>
            <a href="<?=url('/')?>/<?php echo e($toko->username); ?>?previous=toko" style="background: white; padding: 0.2em 1em; color: #ff006e; border-radius: 1.5em; font-size: 0.8em; display: flex; align-items: center;" hidden>Kunjungi Toko</a>
            <?php else: ?>
            <div style="background: #ff006e; padding: 0.2em 1.1em; color: white; border-radius: 1.5em; font-size: 0.8em; display: flex; align-items: center;">Hubungi Toko</div>
            <?php endif; ?>
        </div>

    </div>
</div>
<?php endif; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH D:\xampp\htdocs\kita-pura-mall\resources\views/toko/toko_data.blade.php ENDPATH**/ ?>