<!DOCTYPE html>
<html lang="en">
<head>
    <title></title>
</head>
<body>
    <h3>Kode Untuk Lupa Password</h3>
    <p><?php echo e($data['body']); ?></p>
    <h1><?php echo e($data['otp']); ?></h1>
    <p>Masukkan kode diatas</p>
</body>
</html><?php /**PATH D:\xampp\htdocs\kita-pura-mall\resources\views/mail/send_kode_lupa_password.blade.php ENDPATH**/ ?>