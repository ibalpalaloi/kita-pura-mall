    <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $go_link = url('/')."/".Request::segment(1)."/daftar-menu/$row->id"; ?>
    <div class="slider-toko" style="margin-bottom: 1em; margin-left: 0px;">
        <?php $svg = "public/img/home/bg-slider-toko.svg"; ?>
        <img src="<?=url('/')?>/public/img/toko/<?php echo e($row->toko_id); ?>/produk/240x200/<?php echo e($row->foto_produk); ?>" onclick='go_link("<?=$go_link?>")'>
        <div style='text-align: left; font-size: 0.75em; padding: 0.6em 1em 0.7em 1em; width: 100%; color: white; background-size: cover; position: relative; background: <?php echo e($page->warna_header); ?>;'> 
            <?php if(Auth::user()): ?>
            <div class="" style="width: 5em; position: absolute; height: 5em; bottom:3.5em; right:0.5em; z-index: 1000;">
                <img src="<?=url('/')?>/public/img/mitra/landing_page/keranjang.svg" style="width: 100%; height: 100%;" onclick="masukan_keranjang('<?php echo e($row->toko_id); ?>', '<?php echo e($row->id); ?>')">
            </div>              
            <?php else: ?>
            <a href="<?=url('/')?>" class="" style="width: 5em; position: absolute; height: 5em; bottom:3.5em; right:0.5em; z-index: 1000;">
                <img src="<?=url('/')?>/public/img/mitra/landing_page/keranjang.svg" style="width: 100%; height: 100%;" onclick="masukan_keranjang('<?php echo e($row->toko_id); ?>', '<?php echo e($row->id); ?>')">
            </a>              
            <?php endif; ?>
            <a href="<?=url('/')?>/<?php echo e(Request::segment(1)); ?>/daftar-menu/<?php echo e($row->id); ?>" style="font-weight: 500; margin-top: 0em; color: white; font-size: 1.5em;"><?=ucwords(strtolower(substr(strip_tags($row->nama), 0, 10)))?><?php if(strlen($row->nama) > 10): ?>..<?php endif; ?></a>
            <div style="font-size: 0.8em; line-height: 1.2em; font-weight: 0;"><?php echo e(ucwords(strtolower($row->kategori->nama))); ?></div>
            <div style="padding: 0; margin: 0.5em 0px 0.7em 0px; font-size: 0.8em; line-height: 1em;">
                <i class="fas fa-star star-rating"></i>
                <i class="fas fa-star star-rating"></i>
                <i class="fas fa-star star-rating"></i>
                <i class="fas fa-star star-rating"></i>
                <i class="far fa-star star-rating"></i>
            </div>
            <?php if($row->jenis_harga == 'Statis'): ?>
            <?php if($row->diskon == '0'): ?>
            <span style="padding: 0; margin: 0.1em 0px 0px 0px; font-size: 1.2em; line-height: 0.6em; font-weight: 500;">IDR. <?php echo e(number_format($row->harga,0,',','.')); ?></span>
            <?php else: ?>
            <span style="padding: 0; margin: 0.1em 0px 0px 0px; font-size: 0.6em; line-height: 0.7em; vertical-align: center;">
                <s>IDR. <?php echo e(number_format($row->harga,0,',','.')); ?></s>
            </span>
            <?php
            $hasil_diskon = ($row->harga)-((($row->diskon)/100)*($row->harga));
            ?>

            <span style="padding: 0; margin: 0.1em 0px 0px 0.5em; font-size: 1.2em; line-height: 0.6em; font-weight: 500;">IDR. <?php echo e(number_format($hasil_diskon,0,',','.')); ?></span>
            <?php endif; ?>
            <?php else: ?>
            <span style="padding: 0; margin: 0.1em 0px 0px 0px; font-size: 1.2em; line-height: 0.6em; font-weight: 500;"><span style="font-size: 0.7em;">Harga Mulai</span> IDR. <?php echo e(number_format($row->harga_terendah,0,',','.')); ?></span>

            <?php endif; ?>

        </div>
    </div> 
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH D:\xampp\htdocs\kita-pura-mall\resources\views/landing_page/data_daftar_menu.blade.php ENDPATH**/ ?>