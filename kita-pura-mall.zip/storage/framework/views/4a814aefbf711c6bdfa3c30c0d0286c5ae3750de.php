<!DOCTYPE html>
<html lang="en">
<head>
    <title>Real Programmer</title>
</head>
<body>
    <h3><?php echo e($data['title']); ?></h3>
    <p><?php echo e($data['body']); ?></p>
    <h1><?php echo e($data['otp']); ?></h1>
    <p>Masukkan kode di atas untuk registrasi</p>
</body>
</html><?php /**PATH D:\xampp\htdocs\kita-pura-mall\resources\views/mail/send_gmail.blade.php ENDPATH**/ ?>