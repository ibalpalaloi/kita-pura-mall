

<?php $__env->startSection('title'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-scripts'); ?>
<style type="text/css">
	.banner {
		max-width: 480px;
		width: 100%;
		margin: 0px auto;
		padding: 4em 0em 4em 0em;
	}

	.header {
		background: #ff006e;
		position: fixed;
		width: 100%;
		top: 0px;
		left: 0px;
		right: 0px;
		z-index: 11;				
	}

	.card-mall {
		background: white;
		border-radius: 1.5em;	
		margin-bottom: 1em;
	}

	.kategori {
		padding: 0.8em 0em 1em 0em;
		display: flex; 
		position: relative; 
		top: -3em; 
		margin-bottom: -2em;
		z-index: 1;   
		overflow-y: visible; 
		overflow-x: visible; 			

	}

	.nama-kategori {
		padding: 0.5em 0.5em 0.5em 0.5em;
		display: flex; 				
		justify-content: space-around;
	}

	.sosmed > img {
		margin: 0px 0.6em 0px 0.6em !important;
	}

	.footer {
		position: fixed;
		left: 0;
		bottom: 0;
		width: 100%;
		color: white;
		text-align: center;
		padding-bottom: 0px;
		background-color: transparent;
	}

	.footer-mall-menu {
		background: white;
		border-radius: 3em;         
		margin-bottom: 0.5em;  
	}

	.div-input-mall {
		border-radius: 1.5em; border:1px solid #d1d2d4;		
	}

	.input-group-text-mall {
		border: none;
		display: flex;justify-content: center;
		width: 3em; 
		height: 3em; 
		border-bottom-left-radius: 1.5em; 
		border-top-left-radius: 1.5em; 
		background:white;		
	}

	.form-control-mall {
		height: 3em; 
		border-bottom-right-radius: 1.5em; 
		border-top-right-radius: 1.5em; 
		border-left: none;	
		padding-left: 0.2em;	
	}

	input:focus {
		border: none;
	}

	.form-control {
		border: none;
	}

</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<header class="style__Container-sc-3fiysr-0 header" >
	<div class="style__Wrapper-sc-3fiysr-2 hBSxmh" style="display: flex; justify-content: space-between;">
		<a href="<?=url('/')?>/user/jadi-mitra" style="padding-left: 1em;">
			<img src="<?=url('/')?>/public/img/back.svg">
		</a>
		<a id="defaultheader_logo" title="Kitabisa" style="margin-left: 20px; height:33px;margin-right:20px" href="/">
			<img src="<?=url('/')?>/public/img/logo.svg">
			<img src="<?=url('/')?>/public/img/logo_text.svg">
		</a>
		<div style="margin-right: 2.5em;">
			<img src="<?=url('/')?>/public/img/back.svg" hidden>
		</div>
	</div>
</header>

<div class="wrapper" style="background: #ff006e; position: relative; z-index: -1; padding-top: 8em;">
	<div class="banner" >
	</div>
</div>

<main id="homepage" class="homepage" style="padding: 0px;">
	<div class="card-mall kategori" style="display: flex; justify-content: center; position: relative; flex-direction: column; align-items: center;">
		<img src="<?=url('/')?>/public/img/mitra/register_free.svg" width="75%"  style="top: -11em; position: relative; overflow-x: visible; z-index: 3 !important;">
		<div style="text-align: center;font-size: 1.2em; font-weight: 500; line-height: 1.2em; margin-top: -10em;">
			Hi, Silahkan&nbsp;<span style="color: #fb036b;">lengkapi informasi</span><br>usaha anda
		</div>
		<form id="biodata" style="width: 80%; margin-top: 2em; display: flex; flex-direction: column; align-items: center;">
			<div class="input-group mb-3 div-input-mall" id="div_nama_pemilik">
				<div class="input-group-prepend">
					<span class="input-group-text input-group-text-mall">
						&nbsp;&nbsp;<img src="<?=url('/')?>/public/img/icon_svg/people.svg">
					</span>
				</div>
				<input type="text" class="form-control form-control-mall" id="nama_pemilik" name="nama_pemilik" onfocus="input_focus(this.id)" onblur="input_blur(this.id)" placeholder="Nama Pemilik" aria-label="Nama Pemilik" aria-describedby="basic-addon1">
			</div>
			<div class="input-group mb-3 div-input-mall" id="div_no_hp">
				<div class="input-group-prepend">
					<span class="input-group-text input-group-text-mall">
						<img src="<?=url('/')?>/public/img/icon_svg/handphone.svg">
					</span>
				</div>
				<input type="text" class="form-control form-control-mall" id="no_hp" name="no_hp" onfocus="input_focus(this.id)" onblur="input_blur(this.id)" placeholder="Nomor Handphone" aria-label="no_hp" aria-describedby="basic-addon1">
			</div>
			<div class="input-group mb-3 div-input-mall" id="div_kalender">
				<div class="input-group-prepend">
					<span class="input-group-text input-group-text-mall">
						<img src="<?=url('/')?>/public/img/icon_svg/kalender.svg">
					</span>
				</div>
				<input type="text" class="form-control form-control-mall" id="kalender" name="kalender" onfocus="input_focus(this.id)" onblur="input_blur(this.id)" placeholder="Silahkan Jadwal Buka Tutup" aria-label="kalender" aria-describedby="basic-addon1">
			</div>
			<div class="input-group mb-3 div-input-mall" id="div_username">
				<div class="input-group-prepend">
					<span class="input-group-text input-group-text-mall" style="background: #d1d2d4;">
						&nbsp;<img src="<?=url('/')?>/public/img/icon_svg/maps.svg">
					</span>
				</div>
				<a href="<?=url()->current()?>/pilih-lokasi" class="form-control form-control-mall" style="background: #d1d2d4; vertical-align: center;display: flex; align-items: center;">Pilih Lokasi</a>
			</div>
			<button type="submit" class="btn btn-primary" style="background: #ff006e; margin-top: 0.5em;border: 1px solid #ff006e; border-radius: 1.5em; padding: 0.5em 2em 0.5em 2em; width: 70%;">Daftar
			</button>
		</form>
	</div>
</main>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
<script type="text/javascript">
	function input_focus(id){
		$("#div_"+id).css('border', '1px solid #525f7f');

	}

	function input_blur(id){
		$("#div_"+id).css('border', '1px solid #d1d2d4');		
	}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home_no_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\kita-pura-mall\resources\views/users/user/m-mitra/register.blade.php ENDPATH**/ ?>