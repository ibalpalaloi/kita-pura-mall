

<?php $__env->startSection('content'); ?>
<div class="row">
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.toko', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\kita-pura-mall\resources\views/toko/dashboard.blade.php ENDPATH**/ ?>