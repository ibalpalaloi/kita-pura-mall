


<?php $__env->startSection('title'); ?>
Pengguna
<?php $__env->stopSection(); ?>

<?php
// fungsi untuk konversi tanggal ke indonesia
function tgl_indo($tanggal){
$bulan = array (
1 => 'Januari',
'Februari',
'Maret',
'April',
'Mei',
'Juni',
'Juli',
'Agustus',
'September',
'Oktober',
'November',
'Desember'
);
$pecahkan = explode('-', $tanggal);
return $pecahkan[2] . ' ' . $bulan[ (int)$pecahkan[1] ] . ' ' . $pecahkan[0];
}
?>

<?php $__env->startSection('header-scripts'); ?>

<link href="<?=url('/')?>/public/template/admin/assets/extra-libs/datatables.net-bs4/css/dataTables.bootstrap4.css"
    rel="stylesheet">
<link rel="stylesheet" type="text/css"
    href="<?=url('/')?>/public/template/admin/assets/extra-libs/datatables.net-bs4/css/responsive.dataTables.min.css">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
<div id="editPassModal" class="modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true"
    style="display: none;">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header d-flex align-items-center">
                <h4 class="modal-title">Ubah Password</h4>
            </div>
            <form action="<?=url('/')?>/admin/ubah_password/pengguna" method="post">
                <div class="modal-body">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="recipient-name" class="control-label">Nama</label>
                        <input name="nama" type="text" class="form-control" id="nama" readonly>
                    </div>
                    <div class="form-group">
                        <label for="recipient-name" class="control-label">Nomor Hp</label>
                        <input name="no_hp" type="text" class="form-control" id="no_hp" readonly>
                    </div>
                    <div class="form-group">
                        <label for="recipient-name" class="control-label">Password Baru</label>
                        <input name="password_baru" type="text" class="form-control" id="password">
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default waves-effect" data-dismiss="modal">Tutup </button>
                    <button type="submit" class="btn btn-danger waves-effect waves-light">Ubah</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-title'); ?>
<div class="row">
    <div class="col-lg-3 col-md-4 col-xs-12 justify-content-start d-flex align-items-center">
        <h5 class="font-medium text-uppercase mb-0">Daftar Pengguna</h5>
    </div>
    <div class="col-lg-9 col-md-8 col-xs-12 d-flex justify-content-start justify-content-md-end align-self-center">
        <nav aria-label="breadcrumb" class="mt-2">
            <ol class="breadcrumb mb-0 p-0">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/admin/beranda')); ?>">Beranda</a> </li>
                <li class="breadcrumb-item active" aria-current="page">Daftar Pengguna</li>
            </ol>
        </nav>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="material-card card">
            <div class="card-body">
                <h4 class="card-title">Pengguna</h4>
                <div class="table-responsive">
                    <table id="zero_config" class="table table-striped border">
                        <thead>
                            <tr>
                                <th>No Hp</th>
                                <th>Nama</th>
                                <th>Level Akses</th>
                                <th>Status</th>
                                <th>Email</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><a href=""><?php echo e($data->no_hp); ?></a></td>
                                <?php if(!empty($data->biodata->nama)): ?>
                                <td><?php echo e($data->biodata->nama); ?></td>
                                <?php else: ?>
                                <td></td>
                                <?php endif; ?>
                                <td><a href=""></a><?php echo e($data->level_akses); ?></td>
                                <td><a href=""></a><?php echo e($data->status); ?></td>
                                <td><a href=""></a><?php echo e($data->email); ?></td>
                                <td>
                                    <a class="btn btn-danger btn-circle delete" data-id="<?php echo e($data->id); ?>"><i
                                            class="fa fa-trash"></i> </a>
                                    <a class="btn btn-info btn-circle editPassBtn"><i class="fa fa-pencil-square"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header bg-dark">
                <div class="d-flex flex-row">
                    <div class="mr-auto align-self-center">
                        <h4 class="card-title mb-0 text-white">Pengguna</h4>
                    </div>
                </div>

            </div>
            <div class="card-body">

                <div class="table-responsive m-t-40">
                    <table id="config-table" class="table display table-bordered table-striped no-wrap">
                        <thead>
                            <tr>
                                <th style="width:1%;">No.</th>
                                <th>No. HP</th>
                                <th>Nama</th>
                                <th>Status</th>
                                <th>Email</th>
                                <th>Tanggal Bergabung</th>
                                <th style="width:3%;">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><a href=""><?php echo e($data->no_hp); ?></a></td>
                                <?php if(!empty($data->biodata->nama)): ?>
                                <td><?php echo e($data->biodata->nama); ?></td>
                                <?php else: ?>
                                <td></td>
                                <?php endif; ?>
                                <td><?php echo e(ucfirst($data->status)); ?></td>
                                <td><?php echo e($data->email); ?></td>
                                <td><?php echo e(tgl_indo(date('Y-m-d', strtotime($data->created_at)))); ?></td>
                                <td>
                                    <a class="btn btn-danger btn-circle delete" data-id="<?php echo e($data->id); ?>"><i
                                            class="fa fa-trash"></i> </a>
                                    <a class="btn btn-info btn-circle editPassBtn"><i class="fa fa-pencil-square"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
<script src="<?=url('/')?>/public/template/admin/assets/extra-libs/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?=url('/')?>/public/template/admin/assets/extra-libs/datatables.net-bs4/js/dataTables.responsive.min.js">
</script>
<script src="<?=url('/')?>/public/template/admin/dist/js/pages/datatable/datatable-basic.init.js"></script>

<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script>
    $('.editPassBtn').on('click', function () {
        $('#editPassModal').modal('show');

        $tr = $(this).closest('tr');

        var data = $tr.children("td").map(function () {
            return $(this).text();
        }).get();

        console.log(data);

        $('#no_hp').val(data[1]);
        $('#nama').val(data[2]);
    })

</script>
<script>
    $('.delete').click(function () {
        var data_id = $(this).attr('data-id');
        swal({
                title: "Are you sure?",
                text: "Once deleted, you will not be able to recover this imaginary file!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    window.location = ("<?=url('/')?>/admin/delete/pengguna/" + data_id)
                }
            });
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u5873786/public_html/kitapuramall.com/resources/views/users/admin/m-pengguna/index.blade.php ENDPATH**/ ?>