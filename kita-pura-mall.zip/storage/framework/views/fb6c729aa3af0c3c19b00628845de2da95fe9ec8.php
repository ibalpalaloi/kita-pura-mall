


<?php $__env->startSection('title'); ?>
Daftar Tunggu
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-scripts'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-12">
        <div class="material-card card">
            <div class="card-body">
                <h4 class="card-title">Daftar Tunggu Toko</h4>
                <br>
                <div class="table-responsive">
                    <table class="table table-dark mb-0">
                        <thead>
                            <tr>
                                <th scope="col">No</th>
                                <th scope="col">Nama Toko</th>
                                <th scope="col">Pemilik</th>
                                <th scope="col">No Hp</th>
                                <th scope="col">Alamat</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $no = 1;
                            ?>
                            <?php $__currentLoopData = $daftar_toko; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($no++); ?></td>
                                <td><a href="<?=url('/')?>/admin/manajemen/daftar_tunggu_toko/<?php echo e($data->id); ?>"><?php echo e($data->nama_toko); ?></a></td>
                                <td><?php echo e($data->nama_pemilik); ?></td>
                                <td><?php echo e($data->no_hp); ?></td>
                                <td><?php echo e($data->alamat_toko); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u5873786/public_html/kitapuramall.com/resources/views/users/admin/m-toko/daftar_tunggu.blade.php ENDPATH**/ ?>