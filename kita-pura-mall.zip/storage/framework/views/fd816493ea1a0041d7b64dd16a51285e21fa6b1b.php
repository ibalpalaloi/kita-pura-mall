<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
dbajhvdjavdjavdjvaj
</body>
</html><?php /**PATH D:\xampp\htdocs\kita-pura-mall\resources\views/welcome.blade.php ENDPATH**/ ?>