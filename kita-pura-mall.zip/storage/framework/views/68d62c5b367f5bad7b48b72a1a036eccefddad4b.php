


<?php $__env->startSection('title'); ?>
Beranda
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-scripts'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-title'); ?>
<div class="row">
    <div class="col-lg-3 col-md-4 col-xs-12 justify-content-start d-flex align-items-center">
        <h5 class="font-medium text-uppercase mb-0">Beranda</h5>
    </div>
    <div class="col-lg-9 col-md-8 col-xs-12 d-flex justify-content-start justify-content-md-end align-self-center">
        <nav aria-label="breadcrumb" class="mt-2">
            <ol class="breadcrumb mb-0 p-0">
                <li class="breadcrumb-item active" aria-current="page">Beranda</li>
            </ol>
        </nav>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u5873786/public_html/kitapuramall.com/resources/views/users/admin/beranda.blade.php ENDPATH**/ ?>