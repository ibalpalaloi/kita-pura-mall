<?php

namespace App\Http\Controllers\Mitra;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Session;
use App\Models\Kategori_toko;
use App\Models\Foto_maps;
use App\Models\kelurahan;
use App\Models\Kategori;
use App\Models\Ktp_toko;
use App\Models\toko;
use App\Models\Daftar_tunggu_toko;
use App\Models\product;
use App\Models\Jadwal_toko;
use App\Models\Landing_page_toko;


class MitraController extends Controller
{
	//
	
	public function autocode($kode){
		$timestamp = time(); 
		$random = rand(10, 100);
		$current_date = date('mdYs'.$random, $timestamp); 
		return $kode.$current_date;
	}
	

	public function mitra(){
		$page = Landing_page_toko::where('toko_id', Auth()->user()->toko->id)->get();
		if(count($page)==0){
			return redirect('/akun/mitra/premium/ganti-landing-page');
		}
		$notification = array();
		if(Session::get('progress_biodata') > '5'){
		// if(Session::get('progress_biodata') != '5'){

			$notification = array(
				'message' => 'Biodata Belum Lengkap'
			);     

			return redirect()->back()->with($notification);
		}
		else{

			if(Session::get('status_mitra') == "Belum jadi mitra"){

				return redirect('/akun/jadi-mitra');

			}
			else{

				$toko = toko::where('users_id', Session::get('id_user'))->first();

				// dd($toko->jenis_mitra);

				if($toko){
					$daftar_tunggu = Daftar_tunggu_toko::where('users_id', Session::get('id_user'))->first();
					if ($daftar_tunggu){
						$ktp_toko = Ktp_toko::where('toko_id', $toko->id)->first();
						if ($ktp_toko){
							$notification = array(
								'message' => 'Belum Terverifikasi Upgrade',
								'jenis_mitra' => $daftar_tunggu->jenis_mitra
							);     
							return redirect('/akun')->with($notification);														

						}
						else {
							$notification = array(
								'message' => 'Belum Terverifikasi KTP',
								'jenis_mitra' => $daftar_tunggu->jenis_mitra
							);     
							return redirect('/akun')->with($notification);							

						}
					}
					else {
						if(is_null($toko->longitude) && is_null($toko->latitude)){
							$notification = array(
								'message' => 'Lokasi Maps Belum Ditentukan'
							);     
						}
						return redirect('/akun/mitra/'.$toko->jenis_mitra)->with($notification);						
					}

				}
				else{

					$daftar_tunggu = Daftar_tunggu_toko::where('users_id', Session::get('id_user'))->first();

					$notification = array(
						'message' => 'Belum Terverifikasi',
						'jenis_mitra' => $daftar_tunggu->jenis_mitra
					);     

					return redirect('/akun')->with($notification);
					
				}

			}

		}

	}

	public function uploadCropImage(Request $request)
	{
		$image = $request->image;

		list($type, $image) = explode(';', $image);
		list(, $image)      = explode(',', $image);
		$image = base64_decode($image);
		$image_name= time().'.png';
        // $path = public_path('upload/'.$image_name);

        // file_put_contents($path, $image);

		\Storage::disk('public')->put('img/user/profile_picture/'.$image_name, file_get_contents($request->image));
		return response()->json(['status'=>true]);
	}
}
