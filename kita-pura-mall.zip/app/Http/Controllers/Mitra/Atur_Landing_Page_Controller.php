<?php

namespace App\Http\Controllers\Mitra;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Video_landing_page;
use App\Models\Landing_page_fasilitas_toko;
use App\Models\Toko;
use Session;

class Atur_Landing_Page_Controller extends Controller
{
    //
    


}
