<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class Admin_Manajemen_Toko_Controller extends Controller
{
    //
}
