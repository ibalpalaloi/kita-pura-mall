<!DOCTYPE html>
<html lang="en">
<head>
    <title></title>
</head>
<body>
    <h3>Kode Untuk Lupa Password</h3>
    <p>{{ $data['body'] }}</p>
    <h1>{{$data['otp']}}</h1>
    <p>Masukkan kode diatas</p>
</body>
</html>