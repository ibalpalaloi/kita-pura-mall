<!DOCTYPE html>
<html lang="en">
<head>
    <title>Real Programmer</title>
</head>
<body>
    <h1>{{ $data['title'] }}</h1>
    <p>{{ $data['body'] }}</p>
    <p>Thank you</p>
</body>
</html>