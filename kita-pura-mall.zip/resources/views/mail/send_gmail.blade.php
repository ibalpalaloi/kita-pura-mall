<!DOCTYPE html>
<html lang="en">
<head>
    <title>Real Programmer</title>
</head>
<body>
    <h3>{{ $data['title'] }}</h3>
    <p>{{ $data['body'] }}</p>
    <h1>{{$data['otp']}}</h1>
    <p>Masukkan kode di atas untuk registrasi</p>
</body>
</html>